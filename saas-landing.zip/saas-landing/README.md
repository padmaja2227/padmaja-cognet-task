# SaaS Landing Page

## Setup Instructions

1. Install XAMPP and start Apache + MySQL.
2. Copy the `saas-landing` folder into your `htdocs` directory.
3. Import the database:
   - Open phpMyAdmin (http://localhost/phpmyadmin).
   - Create a database named `saas_landing`.
   - Import `saas_landing_schema.sql`.
4. Update `config.php` with your MySQL credentials if needed:
   - User: root
   - Password: (empty by default in XAMPP)

## Usage
- Open in browser: http://localhost/saas-landing/
- Book a demo form → saves leads to the `leads` table.
- Case studies section → download sample PDFs.

## Files
- `index.php` → Main landing page
- `config.php` → Database connection
- `submit_lead.php` → Form handler
- `case_render.php` + `case_data.php` → Case studies
- `assets/` → PDFs/images
- `saas_landing_schema.sql` → Database schema