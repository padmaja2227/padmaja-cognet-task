<?php
$case_studies = [
  [
    'title' => 'Increased MRR by 3x',
    'client_name' => 'Acme Inc',
    'industry' => 'SaaS',
    'download_url' => 'assets/acme_case.pdf'
  ],
  [
    'title' => 'Reduced Churn by 40%',
    'client_name' => 'Beta Co',
    'industry' => 'FinTech',
    'download_url' => 'assets/beta_case.pdf'
  ],
  [
    'title' => 'Scaled to 1M Users',
    'client_name' => 'Gamma Ltd',
    'industry' => 'E-commerce',
    'download_url' => 'assets/gamma_case.pdf'
  ]
];