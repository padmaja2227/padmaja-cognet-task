<?php
require 'case_data.php';
foreach($case_studies as $c): ?>
  <div class="col-md-4 mb-3">
    <div class="card h-100">
      <div class="card-body">
        <h5 class="card-title"><?= htmlspecialchars($c['title']) ?></h5>
        <p class="card-text">
          <strong>Client:</strong> <?= htmlspecialchars($c['client_name']) ?><br>
          <strong>Industry:</strong> <?= htmlspecialchars($c['industry']) ?>
        </p>
        <a class="btn btn-outline-primary" href="<?= htmlspecialchars($c['download_url']) ?>" download>Download</a>
      </div>
    </div>
  </div>
<?php endforeach; ?>