<?php
require 'config.php'; // include DB connection

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$company = $_POST['company'] ?? '';
$phone = $_POST['phone'] ?? '';

if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  die("Invalid input. Please go back and try again.");
}

$stmt = $pdo->prepare("INSERT INTO leads (name, email, company, phone) VALUES (?, ?, ?, ?)");
$stmt->execute([$name, $email, $company, $phone]);

echo "Thank you! Your details have been saved.";